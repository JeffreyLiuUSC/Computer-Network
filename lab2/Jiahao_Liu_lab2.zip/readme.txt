Name: Jiahao Liu
USCID: 6044109297
Compilation(in viterbi-scf2.usc.edu):
       1. g++ -o Server Server.cpp -lnsl -lresolv
       2. g++ -o Client Client.cpp -lnsl -lresolv
To run:
       1. ./Server
       2. ./Client viterbi-scf2.usc.edu
Reference:
       1. Beej's socket programming tutorial   
