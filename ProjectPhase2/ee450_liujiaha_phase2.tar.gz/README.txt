EE450 Summer 2019

1.Name: Jiahao Liu
2.USCID: 6044109297
3.Departments open input .txt files, parse and read data from it. Departments u
se data to server(Admission), Admission stores the data in .txt file. Students and Admission set up TCP connect and send student GPA and expectation to Admission. After receiving all data, Admission processes data and make admiting decision, send the result to Students and Department by UDP.

4.main.h:#define the static variable and includes files
  socket.h/cpp: socket related code, involving get_in_addr, getsockname, getadd
rinfo, create_socket, connect(client side), setsockopt, bind.
  database.h/cpp: stores the data from Departments
  Admission.h/cpp & AdmissionMessager.h/cpp: create empty database, conduct the
 tcp communication with client and print the information during communication.
  Department.h/cpp & DepartmentMessager.h/cpp & DepartmentParser.h/cpp: read da
ta from local .txt files, do the tcp socket as client, send data to Admission, 
echo the messages from Admission.
  Student.h/cpp & StudengMessager.h/cpp & StudentParser.h/cpp: read data from local .txt files, do the tcp socket as client, send data to Admission, echo the admission result from Admission.
5.To run code(in terminals):
     make all
     ./Admission
     ./Department
     ./Student
6. reference from http://www.beej.us/guide/bgnet/
