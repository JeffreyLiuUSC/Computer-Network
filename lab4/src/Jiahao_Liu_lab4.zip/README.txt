EE450 2019 Summer
Name: Jiahao Liu
Compilation and run: javac STDM
		     java STDM input.txt